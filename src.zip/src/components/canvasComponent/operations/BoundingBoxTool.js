import { v4 as uuidv4 } from 'uuid';

export const activateBoundingBoxTool = (selectedShapes, setShapes, addDesignToHierarchy, stageRef, layerRef, transformerRef) => {
  if (selectedShapes.length > 0 && stageRef.current) {
    const groupRect = calculateBoundingBox(selectedShapes);

    console.log("Bounding Box Calculated Dimensions:", groupRect);

    const designName = prompt("Enter Design Name:");

    if (designName) {
      // Remove Transformer before creating the bounding box
      if (transformerRef && transformerRef.current) {
        transformerRef.current.nodes([]);
        transformerRef.current.getLayer().batchDraw();
      }

      const boundingBoxId = uuidv4();

      // Adjust the child shapes relative to the bounding box origin
      const adjustedChildren = selectedShapes.map(shape => ({
        ...shape,
        parentId: boundingBoxId,
        x: shape.x - groupRect.x,  // Adjust child X relative to the bounding box
        y: shape.y - groupRect.y,  // Adjust child Y relative to the bounding box
        visible: false  // Hide the children shapes since they are now part of the bounding box
      }));

      const boundingBox = {
        id: boundingBoxId,
        type: 'Instance',
        name: designName,  // Set instance name here
        x: groupRect.x,  // Bounding box origin
        y: groupRect.y,  // Bounding box origin
        width: groupRect.width,
        height: groupRect.height,
        stroke: 'blue',
        strokeWidth: 2,
        fill: 'transparent',
        visible: true,
        isInstance: true,
        children: adjustedChildren  // Add the adjusted child shapes
      };

      console.log("Bounding Box Created:", boundingBox);

      setShapes(prevShapes => {
        const updatedShapes = prevShapes
          .filter(shape => !selectedShapes.some(s => s.id === shape.id)) // Remove selected shapes from top-level shapes
          .concat([boundingBox]); // Add bounding box

        console.log("Updated Shapes with Bounding Box:", updatedShapes);
        return updatedShapes;
      });

      const design = {
        id: boundingBox.id,
        name: designName,
        x: boundingBox.x,
        y: boundingBox.y,
        width: boundingBox.width,
        height: boundingBox.height,
      };
      addDesignToHierarchy(design);

      if (layerRef.current) {
        layerRef.current.batchDraw(); // Redraw the layer to ensure the bounding box and text are rendered
      }
    }
  } else {
    alert("No shapes selected!");
  }
};

const calculateBoundingBox = (selectedShapes) => {
  const positions = selectedShapes.map(shape => ({
    x: shape.x,
    y: shape.y,
    width: shape.width,
    height: shape.height,
  }));

  const minX = Math.min(...positions.map(pos => pos.x));
  const minY = Math.min(...positions.map(pos => pos.y));
  const maxX = Math.max(...positions.map(pos => pos.x + pos.width));
  const maxY = Math.max(...positions.map(pos => pos.y + pos.height));

  return { x: minX, y: minY, width: maxX - minX, height: maxY - minY };
};
