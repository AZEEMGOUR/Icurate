let undoStack = [];
let redoStack = [];

const undo = (shapes, setShapes) => {
    if (undoStack.length > 0) {
        redoStack.push([...shapes]);  // Save current state to redo stack
        const lastState = undoStack.pop();
        setShapes(lastState);
    }
};

const saveState = (shapes) => {
    undoStack.push([...shapes]);  // Save a copy of the current state
    redoStack = [];  // Clear the redo stack whenever a new state is saved
};

export { undo, saveState };
