export const updateVisibilityBasedOnHierarchy = (shapes, currentLevel, targetLevel) => {
    const updateShapeVisibility = (shape, level) => {
        if (typeof shape !== 'object' || shape === null) {
            return;
        }

        // Determine if the current shape is within the specified level range
        const isWithinLevelRange = level >= currentLevel && level <= targetLevel;

        // Update the visibility of the shape
        shape.visible = isWithinLevelRange;

        // Recursively handle nested shapes or instances
        if (shape.children && Array.isArray(shape.children)) {
            shape.children.forEach(child => {
                updateShapeVisibility(child, level + 1);  // Increment the level for children
            });
        }
    };

    // Iterate through all top-level shapes and update their visibility
    shapes.forEach(shape => updateShapeVisibility(shape, 0));  // Start with level 0
    return shapes;
};
