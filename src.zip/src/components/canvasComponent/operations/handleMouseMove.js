

const handleMouseMove = (e, isDrawing, newShape, setNewShape, isDraggingMode, selectedShapes, stageRef, lockedLayers, isAllLocked,isRulerActive, startPoint, setEndPoint,lineFinalized, setDistance,  scaleType,
    unit,selectionRect, // Added for selection rectangle
    setSelectionRect,setMousePosition) => {
    //console.log("handleMouseMove triggered");

    const stage = stageRef.current;
    const mousePos = stage.getPointerPosition();
    const scale = stage.scaleX();
    

    

    // Update the mouse position state
    if (mousePos && setMousePosition) {
        // Adjust the mouse position based on zoom level
        const adjustedX = (mousePos.x - stage.width() / 2) / scale;
        const adjustedY = (mousePos.y - stage.height() / 2) / scale;
    
        // Threshold for detecting near the center (0, 0)
        const threshold = 5 / scale; // Adjust the threshold based on zoom level
    
        if (Math.abs(adjustedX) < threshold && Math.abs(adjustedY) < threshold) {
            setMousePosition({ x: 0, y: 0 });
        } else {
            setMousePosition({ x: adjustedX, y: adjustedY });
        }
    }
    
    if (isRulerActive && startPoint && !lineFinalized) {
        const stage = e.target.getStage();
        const pointerPosition = stage.getPointerPosition();
        const scale = stage.scaleX(); // Assuming uniform scaling (same for X and Y)

        if (!pointerPosition) {
            //console.warn("Pointer position is not available.");
            return;
        }

        // Adjust the pointer position based on the stage scale
        let adjustedX = (pointerPosition.x - stage.width() / 2) / scale;
        let adjustedY = (pointerPosition.y - stage.height() / 2) / scale;

        // Apply scale type constraints
        if (scaleType === 'horizontal') {
            adjustedY = startPoint.y;  // Lock movement to horizontal axis
        } else if (scaleType === 'vertical') {
            adjustedX = startPoint.x;  // Lock movement to vertical axis
        } else if (scaleType === 'diagonal') {
            const diagDist = Math.min(Math.abs(adjustedX - startPoint.x), Math.abs(adjustedY - startPoint.y));
            adjustedX = startPoint.x + diagDist * Math.sign(adjustedX - startPoint.x);
            adjustedY = startPoint.y + diagDist * Math.sign(adjustedY - startPoint.y);
        }

        setEndPoint({ x: adjustedX, y: adjustedY });

        const dx = adjustedX - startPoint.x;
        const dy = adjustedY - startPoint.y;

        let dist = Math.sqrt(dx * dx + dy * dy);
        if (unit === 'cm') {
            dist /= 37.7952755906;  // Convert pixels to cm
        } else if (unit === 'inch') {
            dist /= 96;  // Convert pixels to inches
        }

        setDistance(dist.toFixed(2) + ' ' + unit);
        return;
    }

    if (selectionRect && startPoint) {
        const stage = e.target.getStage();
        const pointerPosition = stage.getPointerPosition();
        const adjustedX = pointerPosition.x - stage.width() / 2;
        const adjustedY = pointerPosition.y - stage.height() / 2;

        setSelectionRect(prevRect => ({
            ...prevRect,
            width: adjustedX - startPoint.x,
            height: adjustedY - startPoint.y
        }));
    }



    if (isDrawing) {
        //console.log("Updating new shape while drawing");

        const stage = e.target.getStage();
        const pointerPosition = stage.getRelativePointerPosition();
        const scale = stage.scaleX();
        const adjustedX = pointerPosition.x - stage.width() / 2;
        const adjustedY = pointerPosition.y - stage.height() / 2;

        const updatedShape = {
            ...newShape,
            width: adjustedX - newShape.x,
            height: adjustedY - newShape.y,
        };
        //console.log("Updated shape:", updatedShape);
        setNewShape(updatedShape);
    } else if (isDraggingMode) {
        //console.log("Dragging mode active");

        if (isAllLocked) {
            //console.log("Global lock is active. Dragging is disabled.");
            return; // Prevent dragging if the global lock is active
        }

        const isAnyShapeLocked = selectedShapes.some(shape => lockedLayers[`${shape.layerId}-${shape.datatypeId}`]);

        if (isAnyShapeLocked) {
            //console.log("One or more selected shapes are locked. Dragging is disabled.");
            return; // Exit early if any selected shape is locked, preventing dragging
        }

        const stage = stageRef.current;
        const pointerPosition = stage.getRelativePointerPosition();

        const updatedShapes = selectedShapes.map(shape => ({
            ...shape,
            x: pointerPosition.x - shape.width / 2,
            y: pointerPosition.y - shape.height / 2,

            
        }));

        setNewShape(updatedShapes);
    }
};

export default handleMouseMove;
