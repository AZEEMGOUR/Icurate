let redoStack = [];

const redo = (shapes, setShapes) => {
    if (redoStack.length > 0) {
        const nextState = redoStack.pop();
        setShapes(nextState);
    }
};

const saveState = (shapes) => {
    redoStack.push([...shapes]);  // Save a copy of the current state
};

export { redo, saveState };
