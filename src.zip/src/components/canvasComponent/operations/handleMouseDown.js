import { v4 as uuidv4 } from 'uuid';
import { saveState as saveUndoState } from './undo';
import { handleRulerMouseDown } from './ruler';

const handleMouseDown = (
    e, 
    setIsDrawing, 
    setNewShape, 
    selectedLayer, 
    setSelectedShapes, 
    shapes, 
    selectedShapes, 
    rectangleToolActive, 
    transformerRef, 
    lockedLayers, 
    isAllLocked, 
    isRulerActive, 
    setStartPoint, 
    startPoint, 
    setEndPoint, 
    setLineFinalized, 
    lineFinalized, 
    scaleType, 
    unit, 
    onShapeSelect, 
    setSelectionRect, 
    setIsSelecting 
) => {
    // If no tool is active and not in ruler mode, initiate selection rectangle
    
    // Handle ruler mode
    if (isRulerActive) {
        const stage = e.target.getStage();
        const pointerPosition = stage.getPointerPosition();

        const adjustedX = pointerPosition.x - stage.width() / 2;
        const adjustedY = pointerPosition.y - stage.height() / 2;

        if (!startPoint || lineFinalized) {
            setStartPoint({ x: adjustedX, y: adjustedY });
            setEndPoint(null); 
            setLineFinalized(false); 
            setIsDrawing(true); 
        }
        return;
    }

    // Handle normal shape interaction
    const stage = e.target.getStage();
    const pointerPosition = stage.getRelativePointerPosition();
    const adjustedX = pointerPosition.x - stage.width() / 2;
    const adjustedY = pointerPosition.y - stage.height() / 2;

    if (e.target.getParent() && e.target.getParent().className === 'Transformer') {
        return; 
    }

    if (rectangleToolActive) {
        console.log("Starting new shape");
        setIsDrawing(true);
        const newShape = {
            id: uuidv4(),
            x: adjustedX,
            y: adjustedY,
            width: 0,
            height: 0,
            color: selectedLayer?.color || '#000',
            boundaryColor: selectedLayer?.boundaryColor || '#000',
            pattern: selectedLayer?.pattern.type || 'solid',
            opacity: selectedLayer?.pattern.opacity || 1,
            layerId: selectedLayer?.layer_number || 0,
            datatypeId: selectedLayer?.datatype_number || 0,
            type: 'Rectangle'
        };
        console.log(newShape.x, newShape.y, newShape.height, newShape.width);
        setNewShape(newShape);
        saveUndoState(shapes); 
        return;
    } 
    if (!rectangleToolActive && !isRulerActive) {
        if (e.target === stage) {
            // Deselect shapes only when clicking on an empty part of the Stage
            setSelectedShapes([]);
            onShapeSelect(null);

            if (transformerRef && transformerRef.current) {
                transformerRef.current.nodes([]); // Clear Transformer
                transformerRef.current.getLayer().batchDraw(); // Redraw layer
            }

            setStartPoint({ x: adjustedX, y: adjustedY });
            setSelectionRect({
                x: adjustedX,
                y: adjustedY,
                width: 0,
                height: 0,
                visible: true,
                fill: 'transparent',
                stroke: 'white',
                strokeWidth: 1
            });

            setIsSelecting(true); // Set selection mode
            return;
        } else {
            let smallestShape = null;
            shapes.forEach(shape => {
                if (shape.type === 'Label') {
                    // For labels, calculate width based on the text length and font size
                    const labelWidth = shape.text.length * (shape.fontSize || 20) * 0.6;  // Estimation: adjust as needed
                    const labelHeight = shape.fontSize || 20;  // Assume default font size
                    
                    if (
                        adjustedX > shape.x &&
                        adjustedX < shape.x + labelWidth &&
                        adjustedY > shape.y &&
                        adjustedY < shape.y + labelHeight
                    ) {
                        if (!smallestShape || (labelWidth * labelHeight < smallestShape.width * smallestShape.height)) {
                            smallestShape = shape;
                        }
                    }
                } else if (
                    adjustedX > shape.x &&
                    adjustedX < shape.x + shape.width &&
                    adjustedY > shape.y &&
                    adjustedY < shape.y + shape.height
                ) {
                    if (!smallestShape || (shape.width * shape.height < smallestShape.width * shape.height)) {
                        smallestShape = shape;
                    }
                }
            });

            if (smallestShape) {
                const key = `${smallestShape.layerId}-${smallestShape.datatypeId}`;
                if (lockedLayers[key]) return;

                let updatedSelection;
                if (e.evt.ctrlKey || e.evt.metaKey) {
                    if (selectedShapes.includes(smallestShape)) {
                        updatedSelection = selectedShapes.filter(shape => shape !== smallestShape);
                    } else {
                        updatedSelection = [...selectedShapes, smallestShape];
                    }
                } else {
                    updatedSelection = [smallestShape];
                }

                setSelectedShapes(updatedSelection);
                onShapeSelect(smallestShape);

                if (transformerRef && transformerRef.current) {
                    const nodes = updatedSelection.map(shape => stage.findOne(`#${shape.id}`)).filter(node => node !== null);
                    transformerRef.current.nodes(nodes);
                    transformerRef.current.getLayer().batchDraw();
                }
            } else {
                // Do not deselect when clicking on shapes
                setSelectedShapes([]);
                onShapeSelect(null);
                if (transformerRef && transformerRef.current) {
                    transformerRef.current.nodes([]);
                    transformerRef.current.getLayer().batchDraw();
                }
            }
        }
    }
};

export default handleMouseDown;
