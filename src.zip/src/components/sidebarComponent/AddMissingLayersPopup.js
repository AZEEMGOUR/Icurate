import React from 'react';

const AddMissingLayersPopup = ({ isOpen, onClose, missingLayers = [], onAddLayers }) => {
  const handleAdd = () => {
    // Logic to add new layers to the application
    const newLayers = missingLayers.map((layer) => ({
      layer_number: layer.layer_number,
      datatype_number: layer.datatype_number,
      color: '#ff0000', // Default color
      boundaryColor: '#000000',
      pattern: {
        type: 'solid',
        opacity: 1
      }
    }));
    
    onAddLayers(newLayers); // Pass new layers to the app
    onClose(); // Close the popup
  };

  return isOpen ? (
    <div className="popup-container">
      <div className="popup-content">
        <h3>Missing Layers Detected</h3>
        <ul>
          {Array.isArray(missingLayers) && missingLayers.length > 0 ? (
            missingLayers.map((layer, index) => (
              <li key={index}>
                Layer Number: {layer.layer_number}, Datatype Number: {layer.datatype_number}
              </li>
            ))
          ) : (
            <li>No missing layers</li>
          )}
        </ul>
        {missingLayers.length > 0 && <button onClick={handleAdd}>Add Missing Layers</button>}
        <button onClick={onClose}>Cancel</button>
      </div>
    </div>
  ) : null;
};

export default AddMissingLayersPopup;
