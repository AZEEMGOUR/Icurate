import React, { useEffect, useState } from 'react';
import './PropertyWindow.css';

const PropertyWindow = ({ selectedShapes = [], layers = [], onUpdateShape }) => {
    const [rectangleIndex, setRectangleIndex] = useState(0);
    const [instanceIndex, setInstanceIndex] = useState(0);
    const [labelIndex, setLabelIndex] = useState(0);

    const [rectangles, setRectangles] = useState([]);
    const [instances, setInstances] = useState([]);
    const [labels, setLabels] = useState([]);

    // Group shapes by type when selectedShapes changes
    useEffect(() => {
        const groupedRectangles = selectedShapes.filter(shape => shape.type === 'Rectangle');
        const groupedInstances = selectedShapes.filter(shape => shape.type === 'Instance');
        const groupedLabels = selectedShapes.filter(shape => shape.type === 'Label');

        setRectangles(groupedRectangles);
        setInstances(groupedInstances);
        setLabels(groupedLabels);

        setRectangleIndex(0); // Reset index when new shapes are selected
        setInstanceIndex(0);
        setLabelIndex(0);
    }, [selectedShapes]);

    // Update shape properties and sync with parent component
    const handleChange = (shapeId, property, value, shapeType) => {
        const updateShapeList = (list) =>
            list.map((shape) => (shape.id === shapeId ? { ...shape, [property]: value } : shape));

        if (shapeType === 'Rectangle') {
            setRectangles(updateShapeList(rectangles));
        } else if (shapeType === 'Instance') {
            setInstances(updateShapeList(instances));
        } else if (shapeType === 'Label') {
            setLabels(updateShapeList(labels));
        }

        // Call the update handler to update the shape in the parent component
        onUpdateShape(shapeId, property, value);
    };

    // Prevent the input from deselecting the shape by stopping propagation
    const handleInputChange = (shapeId, property, e, shapeType) => {
        e.stopPropagation(); // Prevent deselection on the canvas
        handleChange(shapeId, property, parseFloat(e.target.value), shapeType);
    };

    const findMatchingLayer = (shape) => {
        return layers.find(
            (layer) =>
                layer.layer_number.toString() === shape.layerId &&
                layer.datatype_number.toString() === shape.datatypeId
        );
    };

    // Render properties for a single Rectangle
    const renderRectangleProperties = (shape) => {
        const matchingLayer = findMatchingLayer(shape);

        return (
            <div key={shape.id} className="property-group">
                <div className="property-header">
                    <div className="property-title rectangle">Rectangle</div>
                </div>
               
                <div className="property-item">{matchingLayer?.layer_name || '--'}</div>
                
                <div className="property-item">{matchingLayer?.datatype_name || '--'}</div>
                <div className="property-item">x-cord</div>
                <div className="property-item">
                    <input
                        type="number"
                        value={shape.x || ''}
                        onChange={(e) => handleInputChange(shape.id, 'x', e, 'Rectangle')}
                    />
                </div>
                <div className="property-item">y-cord</div>
                <div className="property-item">
                    <input
                        type="number"
                        value={shape.y || ''}
                        onChange={(e) => handleInputChange(shape.id, 'y', e, 'Rectangle')}
                    />
                </div>
                <div className="property-item">Width</div>
                <div className="property-item">
                    <input
                        type="number"
                        value={shape.width || ''}
                        onChange={(e) => handleInputChange(shape.id, 'width', e, 'Rectangle')}
                    />
                </div>
                <div className="property-item">Height</div>
                <div className="property-item">
                    <input
                        type="number"
                        value={shape.height || ''}
                        onChange={(e) => handleInputChange(shape.id, 'height', e, 'Rectangle')}
                    />
                </div>
            </div>
        );
    };

    // Render properties for a single Instance
    const renderInstanceProperties = (shape) => {
        return (
            <div key={shape.id} className="property-group">
                <div className="property-header">
                    <div className="property-title instance">Instance</div>
                </div>
                <div className="property-item">Name</div>
                <div className="property-item">
                    <input
                        type="text"
                        value={shape.name || ''}
                        onChange={(e) => handleInputChange(shape.id, 'name', e, 'Instance')}
                    />
                </div>
                <div className="property-item">x-cord</div>
                <div className="property-item">
                    <input
                        type="number"
                        value={shape.x || ''}
                        onChange={(e) => handleInputChange(shape.id, 'x', e, 'Instance')}
                    />
                </div>
                <div className="property-item">y-cord</div>
                <div className="property-item">
                    <input
                        type="number"
                        value={shape.y || ''}
                        onChange={(e) => handleInputChange(shape.id, 'y', e, 'Instance')}
                    />
                </div>
                <div className="property-item">Orientation</div>
                <div className="property-item">
                    <input
                        type="text"
                        value={shape.orientation || ''}
                        onChange={(e) => handleInputChange(shape.id, 'orientation', e, 'Instance')}
                    />
                </div>
            </div>
        );
    };

    // Render properties for a single Label
    const renderLabelProperties = (shape) => {
        return (
            <div key={shape.id} className="property-group">
                <div className="property-header">
                    <div className="property-title label">Label</div>
                </div>
                <div className="property-item">Name</div>
                <div className="property-item">
                    <input
                        type="text"
                        value={shape.text || ''}
                        onChange={(e) => handleInputChange(shape.id, 'name', e, 'Label')}
                    />
                </div>
                <div className="property-item">x-cord</div>
                <div className="property-item">
                    <input
                        type="number"
                        value={shape.x || ''}
                        onChange={(e) => handleInputChange(shape.id, 'x', e, 'Label')}
                    />
                </div>
                <div className="property-item">y-cord</div>
                <div className="property-item">
                    <input
                        type="number"
                        value={shape.y || ''}
                        onChange={(e) => handleInputChange(shape.id, 'y', e, 'Label')}
                    />
                </div>
                <div className="property-item">Size</div>
                <div className="property-item">
                    <input
                        type="number"
                        value={shape.fontSize || ''}
                        onChange={(e) => handleInputChange(shape.id, 'size', e, 'Label')}
                    />
                </div>
                <div className="property-item">Font</div>
                <div className="property-item">
                    <input
                        type="text"
                        value={shape.fontFamily || ''}
                        onChange={(e) => handleInputChange(shape.id, 'font', e, 'Label')}
                    />
                </div>
            </div>
        );
    };

    // Arrow navigation for Rectangle shapes
    const handleNextRectangle = () => {
        setRectangleIndex((prevIndex) => (prevIndex + 1) % rectangles.length);
    };

    const handlePreviousRectangle = () => {
        setRectangleIndex((prevIndex) => (prevIndex - 1 + rectangles.length) % rectangles.length);
    };

    // Arrow navigation for Instance shapes
    const handleNextInstance = () => {
        setInstanceIndex((prevIndex) => (prevIndex + 1) % instances.length);
    };

    const handlePreviousInstance = () => {
        setInstanceIndex((prevIndex) => (prevIndex - 1 + instances.length) % instances.length);
    };

    // Arrow navigation for Label shapes
    const handleNextLabel = () => {
        setLabelIndex((prevIndex) => (prevIndex + 1) % labels.length);
    };

    const handlePreviousLabel = () => {
        setLabelIndex((prevIndex) => (prevIndex - 1 + labels.length) % labels.length);
    };

    return (
        <div className="property-window">
            {/* Rectangle Section */}
            {rectangles.length > 0 && (
                <>
                    <div className="property-header">
                        <div className="property-title rectangle">Rectangles</div>
                        <div className="property-buttons">
                            <button onClick={handlePreviousRectangle}>&#9668;</button>
                            <span>{rectangleIndex + 1}/{rectangles.length}</span>
                            <button onClick={handleNextRectangle}>&#9658;</button>
                        </div>
                    </div>
                    {renderRectangleProperties(rectangles[rectangleIndex])}
                </>
            )}

            {/* Instance Section */}
            {instances.length > 0 && (
                <>
                    <div className="property-header">
                        <div className="property-title instance">Instances</div>
                        <div className="property-buttons">
                            <button onClick={handlePreviousInstance}>&#9668;</button>
                            <span>{instanceIndex + 1}/{instances.length}</span>
                            <button onClick={handleNextInstance}>&#9658;</button>
                        </div>
                    </div>
                    {renderInstanceProperties(instances[instanceIndex])}
                </>
            )}

            {/* Label Section */}
            {labels.length > 0 && (
                <>
                    <div className="property-header">
                        <div className="property-title label">Labels</div>
                        <div className="property-buttons">
                            <button onClick={handlePreviousLabel}>&#9668;</button>
                            <span>{labelIndex + 1}/{labels.length}</span>
                            <button onClick={handleNextLabel}>&#9658;</button>
                        </div>
                    </div>
                    {renderLabelProperties(labels[labelIndex])}
                </>
            )}
        </div>
    );
};

export default PropertyWindow;
