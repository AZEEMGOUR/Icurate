

const handleMouseHover = (shape, setHoveredShape) => {
    setHoveredShape(shape);
};

export default handleMouseHover;
