let undoStack = [];
let redoStack = [];

const undo = (shapes, setShapes) => {
    if (undoStack.length > 0) {
        redoStack.push([...shapes]);  // Save current state to redo stack
        const lastState = undoStack.pop();  // Get the last saved state from the undo stack
        setShapes(lastState);  // Set the shapes to the last state
    }
};

const saveState = (shapes) => {
    undoStack.push([...shapes]);  // Save the current state
    redoStack = [];  // Clear the redo stack whenever a new state is saved
};

export { undo, saveState };
