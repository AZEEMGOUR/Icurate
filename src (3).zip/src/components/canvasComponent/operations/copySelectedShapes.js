const copySelectedShapes = (shapes, selectedShapes, setShapes, setSelectedShapes) => {
  const copiedShapes = selectedShapes.flatMap(shape => {
    if (shape.type === 'instance') {
      // Copy all child shapes of the instance, ensuring `children` exists
      let copiedChildren = [];
      if (Array.isArray(shape.children)) {
        copiedChildren = shape.children.map(child => ({
          ...child,
          id: `${child.id}-copy-${Date.now()}-${Math.random()}`, // Unique ID for each copied child
          x: child.x + 20, // Offset for visibility
          y: child.y + 20,
        }));
      }

      // Find the associated text shape
      const associatedText = shapes.find(s => 
        s.type === 'Text' &&
        s.x === (shape.x + shape.width / 2 - (s.text.length * 4)) &&
        s.y === (shape.y + shape.height / 2 - 8)
      );

      let copiedText = [];
      if (associatedText) {
        copiedText = {
          ...associatedText,
          id: `${associatedText.id}-copy-${Date.now()}-${Math.random()}`, // Unique ID for the copied text
          x: associatedText.x + 20, // Offset for visibility
          y: associatedText.y + 20,
        };
      }

      return [
        {
          ...shape,
          id: `${shape.id}-copy-${Date.now()}-${Math.random()}`, // Unique ID for the copied instance
          x: shape.x + 20, // Offset for visibility
          y: shape.y + 20,
          children: copiedChildren,
        },
        ...copiedChildren,
        copiedText // Include the copied text
      ].filter(Boolean); // Filter out any undefined values
    } else {
      // Copy normal shapes
      return {
        ...shape,
        id: `${shape.id}-copy-${Date.now()}-${Math.random()}`, // Unique ID for each copied shape
        x: shape.x + 20, // Offset for visibility
        y: shape.y + 20,
      };
    }
  });

  setShapes([...shapes, ...copiedShapes]);
  setSelectedShapes(copiedShapes); // Select the newly copied shapes
};

export default copySelectedShapes;
