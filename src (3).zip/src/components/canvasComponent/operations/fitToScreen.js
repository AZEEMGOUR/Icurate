const fitToScreen = (stageRef, layerRef, shapes) => {
  if (stageRef.current && layerRef.current && shapes.length > 0) {
      const stage = stageRef.current;

      // Calculate the bounding box of all shapes
      let minX = Infinity, minY = Infinity, maxX = -Infinity, maxY = -Infinity;

      shapes.forEach(shape => {
          minX = Math.min(minX, shape.x);
          minY = Math.min(minY, shape.y);
          maxX = Math.max(maxX, shape.x + shape.width);
          maxY = Math.max(maxY, shape.y + shape.height);
      });

      const boundingBoxWidth = maxX - minX;
      const boundingBoxHeight = maxY - minY;

      // Calculate scale factors
      const scaleX = window.innerWidth / boundingBoxWidth/2;
      const scaleY = window.innerHeight / boundingBoxHeight/2;
      const scale = Math.min(scaleX, scaleY);  // Choose the smaller scale to fit both width and height

      // Calculate the center of the bounding box
      const boundingBoxCenterX = minX + boundingBoxWidth / 2;
      const boundingBoxCenterY = minY + boundingBoxHeight / 2;

      // Calculate the new stage position to center the bounding box on the screen
      const offsetX = (boundingBoxCenterX * scale) -stage.width() / 4;
      const offsetY = (boundingBoxCenterY * scale) -stage.height() / 4;

      // Apply the calculated scale and position
      stage.scale({ x: scale, y: scale });
      stage.position({ x: offsetX, y: offsetY });
      stage.batchDraw();
  }
};

export default fitToScreen;
