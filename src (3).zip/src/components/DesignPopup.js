import React, { useState } from 'react';
import './DesignPopup.css'; // Import the CSS file

const DesignPopup = ({ isOpen, onClose, onConfirm }) => {
    const [designName, setDesignName] = useState('');

    const handleConfirm = () => {
        if (designName.trim()) {
            onConfirm(designName);
        } else {
            console.error("Design name is empty.");
        }
        onClose();
    };

    return isOpen ? (
        <div className="popup-overlay">
            <div className="popup-content">
                <h3>Create New Design</h3>
                <input
                    type="text"
                    value={designName}
                    onChange={(e) => setDesignName(e.target.value)}
                    placeholder="Enter design name"
                />
                <button onClick={handleConfirm}>Create</button>
                <button onClick={onClose}>Cancel</button>
            </div>
        </div>
    ) : null;
};

export default DesignPopup;
