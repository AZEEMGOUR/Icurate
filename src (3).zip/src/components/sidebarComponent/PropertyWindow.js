import { useEffect, useState } from 'react';
import './PropertyWindow.css';

const PropertyWindow = ({ selectedShapes = [], layers = [], onUpdateShape, stageRef, layerRef }) => {
  const [rectangleIndex, setRectangleIndex] = useState(0);
  const [instanceIndex, setInstanceIndex] = useState(0);
  const [labelIndex, setLabelIndex] = useState(0);
  const [rectangles, setRectangles] = useState([]);
  const [instances, setInstances] = useState([]);
  const [labels, setLabels] = useState([]);
  const [localShapes, setLocalShapes] = useState([]); // Store multiple shapes

  // Group shapes by type when selectedShapes changes
  useEffect(() => {
    const groupedRectangles = selectedShapes.filter((shape) => shape.type === 'Rectangle');
    const groupedInstances = selectedShapes.filter((shape) => shape.type === 'Group');
    const groupedLabels = selectedShapes.filter((shape) => shape.type === 'Label');

    setRectangles(groupedRectangles);
    setInstances(groupedInstances);
    setLabels(groupedLabels);

    setRectangleIndex(0); // Reset index when new shapes are selected
    setInstanceIndex(0);
    setLabelIndex(0);

    // Copy all selected shapes to localShapes for independent editing
    setLocalShapes([...selectedShapes]);
  }, [selectedShapes]);

  // Function to update a specific shape on the Konva canvas
  const updateShapeOnCanvas = (shape, property, value) => {
    if (stageRef && layerRef && shape) {
      const konvaShape = stageRef.current.findOne(`#${shape.id}`);
      if (konvaShape) {
        konvaShape.setAttr(property, value);  // Update the shape's attribute
      }
      layerRef.current.batchDraw();    // Redraw the layer for immediate reflection
    }
  };

  // Handle input changes and update only the currently selected shape in the property window
  const handleInputChange = (property, value, index, shapeType) => {
    const updatedValue = parseFloat(value);

    // Update only the specific shape based on the current index
    const updatedShapes = localShapes.map((shape, i) => {
      if (
        (shapeType === 'Rectangle' && i === rectangleIndex) ||
        (shapeType === 'Group' && i === instanceIndex) ||
        (shapeType === 'Label' && i === labelIndex)
      ) {
        const updatedShape = {
          ...shape,
          [property]: updatedValue
        };

        // Update the shape on the canvas
        updateShapeOnCanvas(updatedShape, property, updatedValue);

        return updatedShape;
      }
      return shape;
    });

    setLocalShapes(updatedShapes); // Update localShapes with the new values
  };

  const findMatchingLayer = (shape) => {
    return layers.find(
      (layer) =>
        layer.layer_number.toString() === shape.layerId &&
        layer.datatype_number.toString() === shape.datatypeId
    );
  };

  // Render properties for a single Rectangle
  const renderRectangleProperties = (shape) => {
    const matchingLayer = findMatchingLayer(shape);

    return (
      <div key={shape.id} className="property-group">
        <div className="property-header">
          <div className="property-title rectangle">Rectangle</div>
        </div>

        <div className="property-item">{matchingLayer?.layer_name || '--'}</div>
        <div className="property-item">{matchingLayer?.datatype_name || '--'}</div>

        {/* x-coordinate */}
        <div className="property-item">x-cord</div>
        <div className="property-item">
          <input
            type="number"
            value={shape.x || ''}
            onChange={(e) => handleInputChange('x', e.target.value, rectangleIndex, 'Rectangle')}
          />
        </div>

        {/* y-coordinate */}
        <div className="property-item">y-cord</div>
        <div className="property-item">
          <input
            type="number"
            value={shape.y || ''}
            onChange={(e) => handleInputChange('y', e.target.value, rectangleIndex, 'Rectangle')}
          />
        </div>

        {/* Width */}
        <div className="property-item">Width</div>
        <div className="property-item">
          <input
            type="number"
            value={shape.width || ''}
            onChange={(e) => handleInputChange('width', e.target.value, rectangleIndex, 'Rectangle')}
          />
        </div>

        {/* Height */}
        <div className="property-item">Height</div>
        <div className="property-item">
          <input
            type="number"
            value={shape.height || ''}
            onChange={(e) => handleInputChange('height', e.target.value, rectangleIndex, 'Rectangle')}
          />
        </div>
      </div>
    );
  };

  // Render properties for a single Instance
  const renderInstanceProperties = (shape) => {
    return (
      <div key={shape.id} className="property-group">
        <div className="property-header">
          <div className="property-title instance">Instance</div>
        </div>

        {/* Name */}
        <div className="property-item">Name</div>
        <div className="property-item">
          <input
            type="text"
            value={shape.name || ''}
            onChange={(e) => handleInputChange('name', e.target.value, instanceIndex, 'Group')}
          />
        </div>

        {/* x-coordinate */}
        <div className="property-item">x-cord</div>
        <div className="property-item">
          <input
            type="number"
            value={shape.x || ''}
            onChange={(e) => handleInputChange('x', e.target.value, instanceIndex, 'Group')}
          />
        </div>

        {/* y-coordinate */}
        <div className="property-item">y-cord</div>
        <div className="property-item">
          <input
            type="number"
            value={shape.y || ''}
            onChange={(e) => handleInputChange('y', e.target.value, instanceIndex, 'Group')}
          />
        </div>

        {/* Orientation */}
        <div className="property-item">Orientation</div>
        <div className="property-item">
          <input
            type="text"
            value={shape.orientation || ''}
            onChange={(e) => handleInputChange('orientation', e.target.value, instanceIndex, 'Group')}
          />
        </div>
      </div>
    );
  };

  // Render properties for a single Label
  const renderLabelProperties = (shape) => {
    return (
      <div key={shape.id} className="property-group">
        <div className="property-header">
          <div className="property-title label">Label</div>
        </div>

        {/* Text */}
        <div className="property-item">Name</div>
        <div className="property-item">
          <input
            type="text"
            value={shape.text || ''}
            onChange={(e) => handleInputChange('text', e.target.value, labelIndex, 'Label')}
          />
        </div>

        {/* x-coordinate */}
        <div className="property-item">x-cord</div>
        <div className="property-item">
          <input
            type="number"
            value={shape.x || ''}
            onChange={(e) => handleInputChange('x', e.target.value, labelIndex, 'Label')}
          />
        </div>

        {/* y-coordinate */}
        <div className="property-item">y-cord</div>
        <div className="property-item">
          <input
            type="number"
            value={shape.y || ''}
            onChange={(e) => handleInputChange('y', e.target.value, labelIndex, 'Label')}
          />
        </div>

        {/* Font Size */}
        <div className="property-item">Size</div>
        <div className="property-item">
          <input
            type="number"
            value={shape.fontSize || ''}
            onChange={(e) => handleInputChange('fontSize', e.target.value, labelIndex, 'Label')}
          />
        </div>

        {/* Font Family */}
        <div className="property-item">Font</div>
        <div className="property-item">
          <input
            type="text"
            value={shape.fontFamily || ''}
            onChange={(e) => handleInputChange('fontFamily', e.target.value, labelIndex, 'Label')}
          />
        </div>
      </div>
    );
  };

  return (
    <div className="property-window">
      {/* Rectangle Section */}
      {rectangles.length > 0 && (
        <>
          <div className="property-header">
            <div className="property-title rectangle">Rectangles</div>
            <div className="property-buttons">
              <button onClick={() => setRectangleIndex((i) => (i - 1 + rectangles.length) % rectangles.length)}>
                &#9668;
              </button>
              <span>{rectangleIndex + 1}/{rectangles.length}</span>
              <button onClick={() => setRectangleIndex((i) => (i + 1) % rectangles.length)}>&#9658;</button>
            </div>
          </div>
          {renderRectangleProperties(localShapes[rectangleIndex])} {/* Pass the shape from localShapes */}
        </>
      )}

      {/* Instance Section */}
      {instances.length > 0 && (
        <>
          <div className="property-header">
            <div className="property-title instance">Instances</div>
            <div className="property-buttons">
              <button onClick={() => setInstanceIndex((i) => (i - 1 + instances.length) % instances.length)}>
                &#9668;
              </button>
              <span>{instanceIndex + 1}/{instances.length}</span>
              <button onClick={() => setInstanceIndex((i) => (i + 1) % instances.length)}>&#9658;</button>
            </div>
          </div>
          {renderInstanceProperties(localShapes[instanceIndex])} {/* Pass the shape from localShapes */}
        </>
      )}

      {/* Label Section */}
      {labels.length > 0 && (
        <>
          <div className="property-header">
            <div className="property-title label">Labels</div>
            <div className="property-buttons">
              <button onClick={() => setLabelIndex((i) => (i - 1 + labels.length) % labels.length)}>
                &#9668;
              </button>
              <span>{labelIndex + 1}/{labels.length}</span>
              <button onClick={() => setLabelIndex((i) => (i + 1) % labels.length)}>&#9658;</button>
            </div>
          </div>
          {renderLabelProperties(localShapes[labelIndex])} {/* Pass the shape from localShapes */}
        </>
      )}
    </div>
  );
};

export default PropertyWindow;
